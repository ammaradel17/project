/* Time Spend In Page */
var seconds = 0,
    counter = document.getElementById('time'),
    timer = setInterval(function () {
        "use strict";
        myTimeFunction();
    }, 1000);

function myTimeFunction() {
    "use strict";
    var hours = Math.floor(seconds / 3600),
        remMinutes = ((seconds % 3600) - (seconds % 60)) / 60,
        remSeconds = seconds % 60;

    if (hours < 10) {
        hours = "0" + hours;
    }
    if (remMinutes < 10) {
        remMinutes = "0" + remMinutes;
    }
    if (remSeconds < 10) {
        remSeconds = "0" + remSeconds;
    }

    counter.innerHTML = hours + " : " + remMinutes + " : " + remSeconds;
    if (seconds >= 0) {
        seconds += 1;
    }

}

/* Form  */
var mypw = document.getElementById('pw'),
    myicon = document.getElementById('icon');

function myfunction() {
    if (mypw.type === 'password') {
        mypw.type = 'text';
        myicon.classList.remove('fa-eye');
        myicon.classList.add('fa-eye-slash');
    } else {
        mypw.type = 'password';
        myicon.classList.remove('fa-eye-slash');
        myicon.classList.add('fa-eye');
    }
}
var firstName = document.getElementById('fn');

firstName.onfocus = function () {
    firstName.removeAttribute('placeholder');
}

firstName.onblur = function () {
    firstName.setAttribute('placeholder', 'Enter Your First Name');
}
var lastName = document.getElementById('ln');


lastName.onfocus = function () {
    lastName.removeAttribute('placeholder');
}

lastName.onblur = function () {
    lastName.setAttribute('placeholder', 'Enter Your First Name');
}
var submit = document.getElementById('sub');
submit.onclick = function () {
    alert('Welcome' + " " + firstName.value + " " + lastName.value + " " + '❤');
}

var phone = document.getElementById('p');


phone.onfocus = function () {
    phone.removeAttribute('placeholder');
}

phone.onblur = function () {
    phone.setAttribute('placeholder', 'Enter Your First Name');
}

var email = document.getElementById('e');


email.onfocus = function () {
    email.removeAttribute('placeholder');
}

email.onblur = function () {
    email.setAttribute('placeholder', 'Enter Your First Name');
}

var password = document.getElementById('pw');


password.onfocus = function () {
    password.removeAttribute('placeholder');
}

password.onblur = function () {
    password.setAttribute('placeholder', 'Enter Your First Name');
}

/* Date Validity */

var er = document.getElementById('err'),
    er2 = document.getElementById('err2'),
    depart1 = document.getElementById('depart1'),
    return1 = document.getElementById('return1'),
    depart2 = document.getElementById('depart2'),
    return2 = document.getElementById('return2'),
    but1 = document.getElementById('but1'),
    but2 = document.getElementById('but2');

return1.oninput = function () {

    try {
        if (new Date(depart1.value) < new Date()) throw "Please Enter A Valid Depart Date.";
        if (new Date(return1.value) <= new Date(depart1.value)) throw "Please Enter A Valid Return Date.";
        if (new Date(return1.value) > new Date(depart1.value)) throw "";
        else {
            er.innerHTML = "";
        }
    }
    catch (err) {
        er.innerHTML = err;
        er.style.color = "#F00";
    }
}
return2.oninput = function () {

    try {
        if (new Date(depart2.value) < new Date()) throw "Please Enter A Valid Depart Date.";
        if (new Date(return2.value) <= new Date(depart2.value)) throw "Please Enter A Valid Return Date.";
        if (new Date(return2.value) > new Date(depart2.value)) throw "";
        else {
            er2.innerHTML = "";
        }
    }
    catch (err) {
        er2.innerHTML = err;
        er2.style.color = "#F00";
    }
};