var dropDown = document.getElementById('drop'),
    ul = document.getElementById('ul'),
    ex = document.getElementById('ex'),
    maxW = "translate3d(30vh,0px,0)",
    minH = "translate3d(165vh,0px,0)";
dropDown.onclick = function () {
    "use strict";
    ul.style.transform = maxW;
    ex.classList.add('fa-times');
};
ex.onclick = function () {
    ul.style.transform = minH;
    ex.classList.remove('fa-times');

}