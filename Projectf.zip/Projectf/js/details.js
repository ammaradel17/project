/* Booking */
var days1 = document.getElementById('days1'),
    days2 = document.getElementById('days2'),
    days3 = document.getElementById('days3'),
    Price1 = document.getElementById('price1'),
    Price2 = document.getElementById('price2'),
    Price3 = document.getElementById('price3');
var myButton = document.getElementById('bookingButton1');
days1.oninput = function () {
    Price1.value = ((parseInt(array[0].Price) * days1.value) + (.1 * parseInt(array[0].Price))) + " €";
}
window.onload = function () {
    Price1.value = "165€";
    Price2.value = "187€";
    Price3.value = "225.5€";
}
myButton.onclick = function () {
    if (myButton.textContent == 'Book Now') {
        myButton.textContent = 'Cancel ✖ ';
        alert("You have booked" + " " + array[0].Discription + " for " + days1.value + " days with " + Price1.value + " ✔");
    } else {
        myButton.textContent = 'Book Now';
        alert("You have canceled the booking ✖");
        days1.value = 1;
    }

}
days1.onchange = function () {
    if (myButton.textContent == 'Cancel ✖ ') {
        myButton.textContent = 'Book Now';
    }
}
days2.oninput = function () {
    Price2.value = ((parseInt(array[1].Price) * days2.value) + (.1 * parseInt(array[1].Price))) + " €";
}
var myButton2 = document.getElementById('bookingButton2');
myButton2.onclick = function () {
    if (myButton2.textContent == 'Book Now') {
        myButton2.textContent = 'Cancel ✖ ';
        alert("You have booked" + " " + array[1].Discription + " for " + days2.value + " days with " + Price2.value + " ✔");
    } else {
        myButton2.textContent = 'Book Now';
        alert("You have canceled the booking ✖");
        days2.value = 1;
    }
}
days2.onchange = function () {
    if (myButton2.textContent == 'Cancel ✖ ') {
        myButton2.textContent = 'Book Now';
    }
}
days3.oninput = function () {
    Price3.value = ((parseInt(array[2].Price) * days3.value) + (.1 * parseInt(array[2].Price))) + " €";
}
var myButton3 = document.getElementById('bookingButton3');
myButton3.onclick = function () {
    if (myButton3.textContent == 'Book Now') {
        myButton3.textContent = 'Cancel ✖ ';
        alert("You have booked" + " " + array[2].Discription + " for " + days3.value + " days with " + Price3.value + " ✔");
    } else {
        myButton3.textContent = 'Book Now';
        alert("You have canceled the booking ✖");
        days3.value = 1;
    }
}
days3.onchange = function () {
    if (myButton3.textContent == 'Cancel ✖ ') {
        myButton3.textContent = 'Book Now';
    }
}
/* Time Spend In Page */
var seconds = 0,
    counter = document.getElementById('time'),
    timer = setInterval(function () {
        "use strict";
        myTimeFunction();
    }, 1000);

function myTimeFunction() {
    "use strict";
    var hours = Math.floor(seconds / 3600),
        remMinutes = ((seconds % 3600) - (seconds % 60)) / 60,
        remSeconds = seconds % 60;

    if (hours < 10) {
        hours = "0" + hours;
    }
    if (remMinutes < 10) {
        remMinutes = "0" + remMinutes;
    }
    if (remSeconds < 10) {
        remSeconds = "0" + remSeconds;
    }

    counter.innerHTML = hours + " : " + remMinutes + " : " + remSeconds;
    if (seconds >= 0) {
        seconds += 1;
    }

}
/* mytable */
var i,
    j;

var mytable = document.createElement('table'),
    htmlDiv = document.getElementsByClassName('art');
document.body.insertBefore(mytable, htmlDiv[0]);
mytable.setAttribute('id', "table");
var array = new Array();
var an = "<a href='#art'>More Details</a>";


for (i = 0; i < 5; i++) {
    var myrows = document.createElement('tr');
    mytable.appendChild(myrows);
    myrows.setAttribute('id', 'r' + i);
    for (j = 0; j < 6; j++) {
        var mydata = document.createElement('td');
        myrows.appendChild(mydata);
        mydata.setAttribute('id', 'd' + i + j);
    }
}


var rooms = {
    Discription: "Junior Suit With Sea View",
    Details: "Bed 1 extra-large double bed",
    VAT: "9%",
    CityTax: "1%",
    Price: '150&euro;',
    More: an
};
array.push(rooms);
rooms = {
    Discription: "Executive Two Bedroom Suit Jacuzzi Sea View",
    Details: "Bed 1 extra-large double bed",
    VAT: "9%",
    CityTax: "1%",
    Price: '170&euro;',
    More: an
};
array.push(rooms);
rooms = {
    Discription: "Executive Two Bedroom Suit Sea View",
    Details: "Beds: 2 single beds",
    VAT: "9%",
    CityTax: "1%",
    Price: '205&euro;',
    More: an
};
array.push(rooms);
rooms = {
    Discription: "Double Suit With Sea View",
    Details: "Beds: 2 single beds",
    VAT: "9%",
    CityTax: "1%",
    Price: '250&euro;',
    More: an
};

array.push(rooms);
let keys = Object.keys(rooms);
console.log(keys);

for (i = 0; i < 6; i++) {
    console.log(keys[0]);
    document.getElementById('d' + 0 + i).innerHTML = keys[i];

}


for (i = 1; i < 5; i++) {
    for (j = 0; j < 5; j++) {
        document.getElementById('d' + i + 0).innerHTML = array[i - 1].Discription;
        document.getElementById('d' + i + 1).innerHTML = array[i - 1].Details;
        document.getElementById('d' + i + 2).innerHTML = array[i - 1].VAT;
        document.getElementById('d' + i + 3).innerHTML = array[i - 1].CityTax;
        document.getElementById('d' + i + 4).innerHTML = array[i - 1].Price;
        document.getElementById('d' + i + 5).innerHTML = an;

    }
};