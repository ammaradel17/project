$(".show1").click(function () {
   $(".s1").toggleClass("fir2");
   $(".h13").toggleClass("h1");
   $(".hide1").slideToggle();
   $(".hide2,.hide3,.hide4").slideUp();
   $(".s2,.s3,.s4").removeClass("fir2");
   $(".jq .show2 h3,.jq .show3 h3,.jq .show4 h3").removeClass("h1");
   $(".minus1").toggleClass("minuses");
   $(".minus2").removeClass("minuses");
   $(".minus3").removeClass("minuses");
   $(".minus4").removeClass("minuses");
});
$(".show2").click(function () {
   $(".s2").toggleClass("fir2");
   $(".h23").toggleClass("h1");
   $(".hide2").slideToggle();
   $(".hide1,.hide3,.hide4").slideUp();
   $(".s1,.s3,.s4").removeClass("fir2");
   $(".jq .show1 h3,.jq .show3 h3,.jq .show4 h3").removeClass("h1");
   $(".minus2").toggleClass("minuses");
   $(".minus1").removeClass("minuses");
   $(".minus3").removeClass("minuses");
   $(".minus4").removeClass("minuses");
});
$(".show3").click(function () {
   $(".s3").toggleClass("fir2");
   $(".h33").toggleClass("h1");
   $(".hide3").slideToggle();
   $(".hide2,.hide1,.hide4").slideUp();
   $(".s2,.s1,.s4").removeClass("fir2");
   $(".jq .show2 h3,.jq .show1 h3,.jq .show4 h3").removeClass("h1");
   $(".minus3").toggleClass("minuses");
   $(".minus2").removeClass("minuses");
   $(".minus1").removeClass("minuses");
   $(".minus4").removeClass("minuses");
});
$(".show4").click(function () {
   $(".s4").toggleClass("fir2");
   $(".h34").toggleClass("h1");
   $(".hide4").slideToggle();
   $(".hide2,.hide3,.hide1").slideUp();
   $(".s2,.s3,.s1").removeClass("fir2");
   $(".jq .show2 h3,.jq .show3 h3,.jq .show1 h3").removeClass("h1");
   $(".minus4").toggleClass("minuses");
   $(".minus2").removeClass("minuses");
   $(".minus3").removeClass("minuses");
   $(".minus1").removeClass("minuses");
});
$(".rese").click(function () {
   $(".l4").show();
   $(this).removeClass("reseh");
   $(".rese1").addClass("reseh");
   $(".l1").hide();
});
$(".rese1").click(function () {
   $(".l1").show();
   $(this).removeClass("reseh");
   $(".rese").addClass("reseh");
   $(".l4").hide();
});
$(window).scroll(function () {
   if ($(this).scrollTop() > 400) {
      $('.up').fadeIn();
   } else {
      $('.up').fadeOut();
   }
});
$(window).scroll(function () {
   if ($(this).scrollTop() > 120) {
      $('.navv').css({ 'transform': 'translate3d(0,0px,0)' });
   } else {
      $('.navv').css({ 'transform': 'translate3d(0,-35px,0)' });
   }
});
window.onload = function onLoad() {
   $(".spinner-wrapper").fadeOut(3000, function () {
      $(".spinner-wrapper").hide();
      $("body").css('overflow', 'visible');
   })
};
const elemCount = 3;
var current = 1;
const eleWidth = 500;
var move = 0;

const nextElement = document.getElementById('next');
const prevElement = document.getElementById('prev');
const sliderThumb = document.getElementById('thumbs');

nextElement.onclick = nextImage;
prevElement.onclick = prevImage;

function nextImage() {
   if (current < elemCount) {
      move += eleWidth;
      sliderThumb.style.transform = 'translatex(-' + move + 'px)';
      current++;
   }
   if (current == 3) {
      nextElement.style.backgroundColor = '#fc06';
   } else {
      nextElement.style.backgroundColor = '#fc0';
      prevElement.style.backgroundColor = '#fc0';
   }
}

function prevImage() {
   if (current > 1) {
      move -= eleWidth;
      sliderThumb.style.transform = 'translatex(-' + move + 'px)';
      current--;
   }
   if (current <= 1) {
      prevElement.style.backgroundColor = '#fc06';
   } else {
      prevElement.style.backgroundColor = '#fc0';
      nextElement.style.backgroundColor = '#fc0';
   }
}
var ss = document.getElementById('ss');
ss.onclick = function myfunction() {
   alert('you have subscribed');
}