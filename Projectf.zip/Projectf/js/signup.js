var mypw = document.getElementById('pw'),
    mypw2 = document.getElementById('pw2'),
    myicon = document.getElementById('icon'),
    myicon2 = document.getElementById('icon2'),
    sub = document.getElementById('sub');

function myfunction() {
    if (mypw.type === 'password') {
        mypw.type = 'text';
        myicon.classList.remove('fa-eye');
        myicon.classList.add('fa-eye-slash');
    } else {
        mypw.type = 'password';
        myicon.classList.remove('fa-eye-slash');
        myicon.classList.add('fa-eye');
    }
}
icon.addEventListener('click', myfunction);
icon2.addEventListener('click', myfunction2);
function myfunction2() {
    if (mypw2.type === 'password') {
        mypw2.type = 'text';
        myicon2.classList.remove('fa-eye');
        myicon2.classList.add('fa-eye-slash');
    } else {
        mypw2.type = 'password';
        myicon2.classList.remove('fa-eye-slash');
        myicon2.classList.add('fa-eye');
    }
}
mypw2.oninput = function () {
    try {
        if (mypw.value != mypw2.value) throw 'please check your paasword';
        else {
            document.getElementById('p1').innerHTML = "";
        }
    }

    catch (err) {
        document.getElementById('p1').innerHTML = err;
    }

}
var firstName = document.getElementById('fn');

firstName.onfocus = function () {
    firstName.removeAttribute('placeholder');
}

firstName.onblur = function () {
    firstName.setAttribute('placeholder', 'Enter Your First Name');
}
var lastName = document.getElementById('ln');


lastName.onfocus = function () {
    lastName.removeAttribute('placeholder');
}

lastName.onblur = function () {
    lastName.setAttribute('placeholder', 'Enter Your Last Name');
}
var email = document.getElementById('e');


email.onfocus = function () {
    email.removeAttribute('placeholder');
}

email.onblur = function () {
    email.setAttribute('placeholder', 'Enter Your Email Adress');
}
mypw.onfocus = function () {
    mypw.removeAttribute('placeholder');
}

mypw.onblur = function () {
    mypw.setAttribute('placeholder', 'Enter Your Password');
}
mypw2.onfocus = function () {
    mypw2.removeAttribute('placeholder');
}

mypw2.onblur = function () {
    mypw2.setAttribute('placeholder', 'Confirm Your Password');
}
